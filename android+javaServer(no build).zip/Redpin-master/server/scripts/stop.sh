#!/bin/sh
kill `cat pid`
rm pid